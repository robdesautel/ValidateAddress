﻿namespace Common.Address.Enumerators
{
    public enum SubqueryType
    {
        country,
        state,
        county,
        city,
        district,
        street,
        houseNumber,
        postalCode
    }
}
