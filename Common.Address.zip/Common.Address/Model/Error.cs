﻿namespace Common.Address.Model
{
    public class Error
    {
        public string? ErrorType { get; set; }
        public string? ErrorNumber { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
